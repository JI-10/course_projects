# Digital-Circuits-Lab
This is a repository for reports of FSM and ALU designed on Quartus using VHDL.
